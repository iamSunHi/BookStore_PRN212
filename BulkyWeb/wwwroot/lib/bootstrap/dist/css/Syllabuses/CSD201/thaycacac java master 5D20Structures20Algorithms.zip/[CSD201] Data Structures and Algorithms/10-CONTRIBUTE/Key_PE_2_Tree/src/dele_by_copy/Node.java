package dele_by_copy;

public class Node {
   int info;
   Node left,right;
   Node() {
   }
   Node(int x) {
     info=x;
     left=right=null;
   }
}
